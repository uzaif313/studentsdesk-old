var studentApp=angular.module("studentApp",['ngRoute','flash', 'ngAnimate'])
studentApp.config([
  "$httpProvider", function($httpProvider) {
    $httpProvider.defaults.headers.common['X-CSRF-Token'] = $('meta[name=csrf-token]').attr('content');
  }
]);

var teacherApp=angular.module("teacherApp",['ngRoute'])
  studentApp.config([
  "$httpProvider", function($httpProvider) {
    $httpProvider.defaults.headers.common['X-CSRF-Token'] = $('meta[name=csrf-token]').attr('content');
  }
]);
